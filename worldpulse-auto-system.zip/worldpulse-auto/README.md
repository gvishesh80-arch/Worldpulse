# 🗞️ WorldPulse — Automated Daily Blog System

> Your blog publishes itself every morning at 6 AM. Zero effort after setup.

---

## How It Works

```
6:00 AM UTC every day
      ↓
GitHub Actions wakes up
      ↓
Calls Claude API (Anthropic)
      ↓
Claude researches real news + writes full blog post
      ↓
HTML file committed to this repo
      ↓
Netlify detects change, deploys in 30 seconds
      ↓
Your blog is live with today's news ✅
```

**Your effort after setup: ZERO.**

---

## One-Time Setup (~15 minutes)

### Step 1 — Get a Claude API Key (5 minutes)
1. Go to **console.anthropic.com**
2. Sign up for a free account
3. Go to **API Keys** → **Create Key**
4. Copy the key (starts with `sk-ant-...`)
5. Keep it secret — treat it like a password

### Step 2 — Create GitHub Repository (2 minutes)
1. Go to **github.com** → Sign up free
2. Click **New Repository**
3. Name it: `worldpulse-blog`
4. Make it **Public**
5. Click **Create repository**

### Step 3 — Upload These Files (3 minutes)
Upload the entire contents of this folder to your GitHub repo:
```
worldpulse-blog/
├── .github/
│   └── workflows/
│       └── daily-publish.yml    ← The automation
├── scripts/
│   └── publish.py               ← The publisher script
├── index.html                   ← Gets replaced daily
└── README.md                    ← This file
```

### Step 4 — Add Your API Key (2 minutes)
1. In your GitHub repo, go to **Settings**
2. Click **Secrets and variables** → **Actions**
3. Click **New repository secret**
4. Name: `ANTHROPIC_API_KEY`
5. Value: paste your key from Step 1
6. Click **Add secret**

### Step 5 — Connect Netlify (3 minutes)
1. Go to **netlify.com** → Sign in
2. Click **Add new site** → **Import from Git**
3. Choose **GitHub** → Select your `worldpulse-blog` repo
4. Build settings: leave blank (it's just HTML)
5. Click **Deploy site**
6. Your domain: connect `worldpulse.blog` in Domain settings

---

## That's It. Your Blog is Now Automated.

Every day at 6 AM UTC:
- A new blog is generated with **real news** from that day
- It covers: geopolitics, economy, science, conflict, Claude AI
- Every article is 500-800 words with real facts and analysis
- All links work — navigation, categories, article pages
- The Claude AI column runs every day

---

## Cost

| Item | Cost |
|------|------|
| GitHub | **Free** |
| Netlify | **Free** |
| Claude API (per daily post) | **~$0.50–$2.00** |
| Domain (worldpulse.blog) | **~$5/year** |
| **Total monthly** | **~$15–60/month** |

---

## Making Money From Your Blog

Once you have consistent daily traffic:

### Google AdSense
- Apply at: adsense.google.com
- Eligibility: 6+ months old, real content, original articles ✅
- Revenue: $2–$10 per 1,000 visitors (RPM)

### Ezoic (better than AdSense)
- Apply at: ezoic.com
- No minimum traffic requirement
- Revenue: $5–$25 RPM (much better than AdSense)

### Newsletter Sponsorships
- Once you have 1,000+ subscribers
- Charge $100–$500 per sponsored issue
- Connect the subscribe button to Mailchimp (free)

### Premium Membership
- Use Memberful or Patreon
- Offer ad-free reading + exclusive analysis
- $5–$15/month per member

---

## Customizing Your Blog

Edit `scripts/publish.py` to change:

```python
BLOG_TITLE = "WorldPulse"          # Your blog name
BLOG_TAGLINE = "Global Intelligence · Daily"
BLOG_DOMAIN = "worldpulse.blog"    # Your domain
MODEL = "claude-sonnet-4-20250514" # Claude model to use
```

The system prompt controls what Claude writes about.
Edit `SYSTEM_PROMPT` to focus on specific topics (sports, tech, business, etc.).

---

## Manual Trigger

To publish immediately without waiting for 6 AM:
1. Go to your GitHub repo
2. Click **Actions** tab
3. Click **Daily Blog Publisher**
4. Click **Run workflow** → **Run workflow**
5. Blog publishes in ~2 minutes

---

## Files in This Repo

| File | Purpose |
|------|---------|
| `.github/workflows/daily-publish.yml` | GitHub Actions automation schedule |
| `scripts/publish.py` | Main publisher — calls Claude API, builds HTML |
| `index.html` | Today's blog post (auto-replaced daily) |

---

## Support

If the workflow fails, check:
1. **API key** is correctly set in GitHub Secrets
2. **Anthropic account** has available credits
3. **GitHub Actions** are enabled for your repo (Settings → Actions)

---

*Built with Claude AI · WorldPulse · Daily Global Journalism*
