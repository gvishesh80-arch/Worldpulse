#!/usr/bin/env python3
"""
WorldPulse Daily Auto-Publisher
================================
This script runs every day at 6 AM (via GitHub Actions or cron).
It calls the Claude API to research and write today's blog,
then saves the HTML so GitHub/Netlify deploys it automatically.

SETUP INSTRUCTIONS:
  1. Get a Claude API key from console.anthropic.com
  2. Add it as ANTHROPIC_API_KEY in your GitHub repository secrets
  3. Push this repo to GitHub
  4. GitHub Actions runs this script daily at 6 AM UTC
  5. Netlify watches your GitHub repo and deploys automatically

That's it. Your blog updates itself every single day.
"""

import os
import json
import urllib.request
import urllib.error
import datetime
import sys

# ─────────────────────────────────────────────
# CONFIGURATION — Edit these to customize
# ─────────────────────────────────────────────
BLOG_TITLE = "WorldPulse"
BLOG_TAGLINE = "Global Intelligence · Daily"
BLOG_DOMAIN = "worldpulse.blog"          # Your domain
OUTPUT_FILE = "index.html"               # Output file for Netlify
API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
MODEL = "claude-sonnet-4-20250514"       # Best model for cost/quality balance
MAX_TOKENS = 8000

# ─────────────────────────────────────────────
# PROMPTS
# ─────────────────────────────────────────────

SYSTEM_PROMPT = """You are the chief editor and lead journalist of WorldPulse, a world-class global news blog. 
Your job is to produce today's complete daily blog edition.

You must write about REAL events happening TODAY. Today's date is: {today}

You will produce a JSON object with this exact structure:
{{
  "date": "Tuesday, April 22, 2026",
  "edition": "Daily Edition",
  "breaking_ticker": ["headline 1", "headline 2", "headline 3", "headline 4", "headline 5"],
  "markets": [
    {{"label": "S&P 500", "value": "5,228", "change": "▲ +0.4%", "dir": "up"}},
    {{"label": "Crude Oil", "value": "$81.2", "change": "▼ -0.8%", "dir": "down"}},
    {{"label": "Gold", "value": "$2,398", "change": "▲ +0.3%", "dir": "up"}},
    {{"label": "EUR/USD", "value": "1.071", "change": "▼ -0.1%", "dir": "down"}},
    {{"label": "10Y Treasury", "value": "4.68%", "change": "▲ +2bps", "dir": "up"}}
  ],
  "articles": [
    {{
      "id": "unique-slug",
      "cat": "Geopolitics",
      "tag": "Breaking · Crisis",
      "headline": "Full Compelling Headline Here",
      "deck": "150-200 word summary of the story that makes reader want to click",
      "author": "Author Name",
      "role": "Senior Correspondent",
      "time": "Today, 8:30 AM",
      "read_time": "6 min read",
      "hero_icon": "🌍",
      "hero_color": "#0f1520",
      "body_html": "<p>Full article HTML here — at least 600 words, with h3 subheadings, blockquotes with real quotes, and a fact-box div...</p>"
    }}
  ],
  "claude_ai_article": {{
    "id": "claude-ai-today",
    "headline": "Claude AI Column Headline",
    "deck": "AI column deck",
    "author": "James Park",
    "role": "AI & Technology Correspondent",
    "time": "Today, 6:00 AM",
    "read_time": "8 min read",
    "hero_icon": "🧠",
    "body_html": "<p>Full Claude AI article HTML — 600+ words about what Anthropic/Claude is doing today, what it means for humanity, benefits and risks...</p>"
  }},
  "live_updates": [
    {{"tag": "war", "tag_label": "Conflict", "text": "<strong>Story:</strong> Update text here"}},
    {{"tag": "econ", "tag_label": "Markets", "text": "<strong>Story:</strong> Update text"}},
    {{"tag": "ai", "tag_label": "Tech", "text": "<strong>Story:</strong> Update text"}},
    {{"tag": "diplo", "tag_label": "Diplomacy", "text": "<strong>Story:</strong> Update text"}}
  ]
}}

CRITICAL RULES:
- Write about REAL news happening today — {today}
- Every article body must be 500+ words with real facts, quotes, analysis
- Include at least 5 articles covering: geopolitics, economy, science/health, conflict, AND Claude AI
- The Claude AI article is mandatory every day — what Anthropic/AI industry is doing RIGHT NOW
- All quotes must be real, attributed, with proper citation format
- fact-box format: <div class="fact-box"><div class="fact-box-title">📋 Key Facts</div><ul><li><span>Label</span><strong>Value</strong></li></ul></div>
- Market data should reflect real approximate values for today
- Return ONLY valid JSON — no markdown, no backticks, no explanation outside the JSON
"""

USER_PROMPT = """Today is {today}. 

Write the complete WorldPulse daily blog edition for today. Include:
1. The single most important world story today as the lead article (full 600+ word article)
2. The Gaza/Middle East situation update  
3. The Claude AI weekly column (what Anthropic is building, what it means for humanity)
4. 2-3 more major world stories (conflict, economy, science — whatever is most important TODAY)
5. 5 live update items

Research what is actually happening in the world RIGHT NOW on {today} and write about it.
Make it feel like a real newspaper — specific facts, real quotes, real context.

Return the complete JSON object described in your instructions."""

# ─────────────────────────────────────────────
# HTML TEMPLATE — The complete blog design
# ─────────────────────────────────────────────

HTML_TEMPLATE = '''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta name="description" content="{blog_title} — {tagline}. Published {date}."/>
<meta property="og:title" content="{blog_title} — {date}"/>
<meta property="og:description" content="{blog_title}: World-class global journalism published daily."/>
<title>{blog_title} — {date}</title>
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;0,900;1,700&family=Source+Serif+4:opsz,wght@8..60,300;8..60,400&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet"/>
<style>
:root{{--ink:#0f0e0d;--paper:#f6f2ea;--cream:#faf7f2;--red:#c41e3a;--gold:#b8860b;--teal:#1a5f7a;--rule:#ddd6c8;--mist:#8a8680;--surf:#fff;--blue:#1a3a5c;--green:#1a4a2e;}}
*{{margin:0;padding:0;box-sizing:border-box;}}
html{{scroll-behavior:smooth;}}
body{{background:var(--paper);color:var(--ink);font-family:"Source Serif 4",Georgia,serif;font-size:17px;line-height:1.7;}}
.ticker{{background:var(--red);color:#fff;height:34px;display:flex;overflow:hidden;position:sticky;top:0;z-index:200;}}
.ticker-tag{{background:#000;color:#fff;padding:0 14px;font-family:"Space Mono",monospace;font-size:10px;letter-spacing:2px;display:flex;align-items:center;flex-shrink:0;text-transform:uppercase;}}
.ticker-track{{overflow:hidden;flex:1;display:flex;align-items:center;}}
.ticker-inner{{display:flex;white-space:nowrap;animation:tick 50s linear infinite;}}
.ticker-inner span{{font-size:11px;padding:0 36px;}}
.ticker-inner span::after{{content:"◆";margin-left:36px;opacity:.4;}}
@keyframes tick{{0%{{transform:translateX(0)}}100%{{transform:translateX(-50%)}}}}
.masthead{{background:var(--ink);padding:0 32px;border-bottom:3px solid var(--red);}}
.mast-top{{display:flex;align-items:center;justify-content:space-between;padding:18px 0 14px;border-bottom:1px solid rgba(255,255,255,.08);}}
.mast-date{{font-family:"Space Mono",monospace;font-size:10px;color:rgba(255,255,255,.45);letter-spacing:1px;text-transform:uppercase;}}
.mast-logo{{text-align:center;flex:1;}}
.logo-name{{font-family:"Playfair Display",serif;font-weight:900;font-size:clamp(2rem,5vw,3.8rem);color:#fff;letter-spacing:-1px;line-height:1;text-transform:uppercase;cursor:pointer;text-decoration:none;display:block;}}
.logo-name span{{color:var(--red);}}
.logo-tag{{font-family:"Space Mono",monospace;font-size:9px;color:rgba(255,255,255,.35);letter-spacing:4px;text-transform:uppercase;margin-top:3px;}}
.mast-actions{{display:flex;gap:10px;align-items:center;}}
.btn-sub{{background:var(--red);color:#fff;border:none;padding:7px 16px;font-family:"Space Mono",monospace;font-size:10px;letter-spacing:1px;text-transform:uppercase;cursor:pointer;}}
.nav{{display:flex;overflow-x:auto;scrollbar-width:none;}}
.nav::-webkit-scrollbar{{display:none;}}
.nav-item{{font-family:"Space Mono",monospace;font-size:10px;letter-spacing:1.5px;text-transform:uppercase;color:rgba(255,255,255,.5);padding:12px 18px;cursor:pointer;border-bottom:3px solid transparent;white-space:nowrap;user-select:none;text-decoration:none;transition:color .2s;}}
.nav-item:hover,.nav-item.active{{color:#fff;}}
.nav-item.active{{border-bottom-color:var(--red);}}
.markets{{display:flex;gap:0;background:var(--cream);border-bottom:2px solid var(--rule);overflow-x:auto;padding:0 32px;}}
.m-item{{display:flex;align-items:center;gap:8px;padding:9px 20px 9px 0;border-right:1px solid var(--rule);white-space:nowrap;}}
.m-item:last-child{{border-right:none;}}
.m-label{{font-family:"Space Mono",monospace;font-size:9px;letter-spacing:1px;color:var(--mist);text-transform:uppercase;}}
.m-val{{font-family:"Space Mono",monospace;font-size:12px;font-weight:700;color:var(--ink);}}
.m-chg{{font-family:"Space Mono",monospace;font-size:10px;}}
.up{{color:#2a9e60;}}.down{{color:var(--red);}}
.container{{max-width:1220px;margin:0 auto;padding:0 32px;}}
.sec-hd{{display:flex;align-items:center;gap:14px;margin:40px 0 22px;}}
.sec-title{{font-family:"Playfair Display",serif;font-size:1.5rem;font-weight:900;text-transform:uppercase;color:var(--ink);}}
.sec-rule{{flex:1;height:2px;background:var(--rule);}}
.sec-rule.red{{background:var(--red);}}
.hero-grid{{display:grid;grid-template-columns:1.55fr 1fr;gap:2px;background:var(--rule);border:2px solid var(--rule);margin-top:32px;}}
.hero-lead{{background:var(--surf);padding:28px 32px;position:relative;}}
.hero-lead::before{{content:"";position:absolute;top:0;left:0;right:0;height:4px;background:var(--red);}}
.hero-img{{width:100%;height:280px;display:flex;align-items:center;justify-content:center;font-size:80px;margin-bottom:20px;cursor:pointer;position:relative;overflow:hidden;}}
.kicker{{font-family:"Space Mono",monospace;font-size:9px;letter-spacing:2px;text-transform:uppercase;color:var(--red);border-top:2px solid var(--red);padding-top:5px;display:inline-block;margin-bottom:10px;}}
.kicker.teal{{color:var(--teal);border-top-color:var(--teal);}}
.kicker.gold{{color:var(--gold);border-top-color:var(--gold);}}
h1.hero-hl{{font-family:"Playfair Display",serif;font-weight:900;font-size:clamp(1.6rem,2.6vw,2.3rem);line-height:1.15;color:var(--ink);margin-bottom:14px;}}
.deck{{font-size:15px;color:#444;line-height:1.7;font-weight:300;margin-bottom:14px;}}
.byline{{font-family:"Space Mono",monospace;font-size:9px;color:var(--mist);letter-spacing:.8px;text-transform:uppercase;padding-top:12px;border-top:1px solid var(--rule);}}
.byline strong{{color:var(--ink);}}
.read-btn{{font-family:"Space Mono",monospace;font-size:10px;letter-spacing:1px;text-transform:uppercase;color:var(--red);cursor:pointer;display:inline-flex;align-items:center;gap:5px;margin-top:10px;text-decoration:none;border-bottom:1px solid transparent;transition:border-color .2s;}}
.read-btn:hover{{border-bottom-color:var(--red);}}
.hero-side{{background:var(--surf);padding:22px 26px;}}
.hero-side+.hero-side{{border-top:2px solid var(--rule);}}
.side-img{{width:100%;height:110px;margin-bottom:12px;display:flex;align-items:center;justify-content:center;font-size:38px;cursor:pointer;}}
.hl2{{font-family:"Playfair Display",serif;font-weight:700;font-size:1.05rem;line-height:1.3;color:var(--ink);cursor:pointer;margin-bottom:6px;}}
.hl2:hover{{color:var(--red);}}
.deck2{{font-size:13px;color:#555;line-height:1.6;font-weight:300;}}
.card-grid{{display:grid;grid-template-columns:repeat(3,1fr);gap:2px;background:var(--rule);border:2px solid var(--rule);}}
.card{{background:var(--surf);padding:22px;cursor:pointer;transition:background .15s;}}
.card:hover{{background:#fffef9;}}
.card-img{{width:100%;height:140px;display:flex;align-items:center;justify-content:center;font-size:40px;margin-bottom:14px;}}
.hl3{{font-family:"Playfair Display",serif;font-weight:700;font-size:.98rem;line-height:1.3;color:var(--ink);margin-bottom:6px;}}
.deck3{{font-size:12px;color:#555;line-height:1.6;font-weight:300;}}
.dark-feat{{background:var(--ink);padding:38px 44px;display:grid;grid-template-columns:1.3fr 1fr;gap:40px;align-items:center;cursor:pointer;margin:2px 0;position:relative;overflow:hidden;}}
.dark-feat::before{{content:"";position:absolute;inset:0;background:radial-gradient(ellipse at 70% 50%,rgba(196,30,58,.07),transparent 60%);}}
.df-kicker{{font-family:"Space Mono",monospace;font-size:9px;letter-spacing:2px;text-transform:uppercase;color:rgba(232,160,160,.8);border-top:2px solid var(--red);padding-top:5px;display:inline-block;margin-bottom:12px;}}
.df-hl{{font-family:"Playfair Display",serif;font-weight:900;font-size:clamp(1.4rem,2.2vw,2rem);line-height:1.2;color:#fff;margin-bottom:12px;}}
.df-deck{{font-size:14px;color:rgba(255,255,255,.6);line-height:1.7;font-weight:300;}}
.df-read{{font-family:"Space Mono",monospace;font-size:10px;letter-spacing:1px;color:rgba(232,160,160,.8);display:inline-flex;align-items:center;gap:5px;margin-top:12px;text-decoration:none;}}
.df-vis{{font-size:100px;opacity:.14;text-align:center;}}
.op-strip{{display:grid;grid-template-columns:repeat(4,1fr);gap:2px;background:var(--rule);border:2px solid var(--rule);}}
.op-card{{background:#fff;padding:22px;border-top:4px solid;cursor:pointer;transition:background .15s;}}
.op-card:hover{{background:var(--cream);}}
.op-card:nth-child(1){{border-top-color:var(--red);}}
.op-card:nth-child(2){{border-top-color:var(--blue);}}
.op-card:nth-child(3){{border-top-color:var(--green);}}
.op-card:nth-child(4){{border-top-color:var(--gold);}}
.op-label{{font-family:"Space Mono",monospace;font-size:8px;letter-spacing:1.5px;text-transform:uppercase;color:var(--mist);margin-bottom:8px;}}
.op-av{{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-family:"Playfair Display",serif;font-weight:700;font-size:14px;margin-bottom:9px;}}
.op-author{{font-family:"Space Mono",monospace;font-size:8px;color:var(--mist);text-transform:uppercase;margin-bottom:6px;}}
.op-hl{{font-family:"Playfair Display",serif;font-style:italic;font-size:.9rem;line-height:1.4;color:var(--ink);}}
.live-sec{{background:var(--ink);padding:34px 0;margin:40px 0;}}
.live-badge{{display:inline-flex;align-items:center;gap:7px;background:var(--red);color:#fff;font-family:"Space Mono",monospace;font-size:10px;letter-spacing:2px;padding:5px 12px;text-transform:uppercase;margin-bottom:18px;}}
.live-dot{{width:7px;height:7px;background:#fff;border-radius:50%;animation:blink 1.4s ease infinite;}}
@keyframes blink{{0%,100%{{opacity:1}}50%{{opacity:.3}}}}
.live-title{{font-family:"Playfair Display",serif;font-size:1.4rem;font-weight:900;color:#fff;margin-bottom:22px;}}
.u-item{{display:grid;grid-template-columns:90px 1fr;gap:16px;padding:14px 0;border-bottom:1px solid rgba(255,255,255,.07);}}
.u-time{{font-family:"Space Mono",monospace;font-size:11px;color:var(--red);}}
.u-text{{font-size:13px;color:rgba(255,255,255,.78);line-height:1.6;}}
.u-text strong{{color:#fff;}}
.utag{{display:inline-block;font-family:"Space Mono",monospace;font-size:8px;letter-spacing:1px;padding:2px 7px;margin-right:6px;text-transform:uppercase;border:1px solid;}}
.utag.war{{border-color:#ff7070;color:#ff7070;}}
.utag.econ{{border-color:#60c878;color:#60c878;}}
.utag.ai{{border-color:#a090f0;color:#a090f0;}}
.utag.diplo{{border-color:#f0c040;color:#f0c040;}}
.utag.sci{{border-color:#60aaf0;color:#60aaf0;}}
.bot-grid{{display:grid;grid-template-columns:2fr 320px;gap:2px;background:var(--rule);border:2px solid var(--rule);margin-bottom:40px;}}
.most-read{{background:var(--surf);padding:26px;}}
.mr-item{{display:grid;grid-template-columns:32px 1fr;gap:12px;padding:13px 0;border-bottom:1px solid var(--rule);cursor:pointer;}}
.mr-item:last-child{{border-bottom:none;}}
.mr-item:hover .mr-title{{color:var(--red);}}
.mr-num{{font-family:"Playfair Display",serif;font-size:1.7rem;font-weight:900;color:var(--rule);line-height:1;}}
.mr-title{{font-family:"Playfair Display",serif;font-size:.88rem;font-weight:700;color:var(--ink);line-height:1.3;margin-bottom:2px;}}
.mr-meta{{font-size:11px;color:var(--mist);}}
.sidebar{{background:var(--surf);}}
.sb-w{{padding:20px;border-bottom:2px solid var(--rule);}}
.sb-w:last-child{{border-bottom:none;}}
.sb-title{{font-family:"Space Mono",monospace;font-size:8px;letter-spacing:2px;text-transform:uppercase;color:var(--mist);margin-bottom:12px;padding-bottom:6px;border-bottom:2px solid var(--rule);}}
.nl-w{{background:var(--cream);padding:18px;}}
.nl-w p{{font-size:12px;color:#555;margin-bottom:10px;line-height:1.5;}}
.nl-w input{{width:100%;border:1px solid var(--rule);padding:8px 10px;font-size:13px;background:#fff;margin-bottom:7px;outline:none;}}
.nl-w button{{width:100%;background:var(--ink);color:#fff;border:none;padding:9px;font-family:"Space Mono",monospace;font-size:10px;letter-spacing:2px;cursor:pointer;}}
footer{{background:var(--ink);color:rgba(255,255,255,.4);padding:34px 32px;margin-top:56px;}}
.ft-inner{{max-width:1220px;margin:0 auto;display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:34px;padding-bottom:26px;border-bottom:1px solid rgba(255,255,255,.08);}}
.ft-logo{{font-family:"Playfair Display",serif;font-weight:900;font-size:1.6rem;color:#fff;text-decoration:none;display:block;}}
.ft-logo span{{color:var(--red);}}
.ft-brand p{{margin-top:9px;font-size:12px;line-height:1.7;}}
.ft-col h4{{font-family:"Space Mono",monospace;font-size:9px;letter-spacing:2px;text-transform:uppercase;color:rgba(255,255,255,.6);margin-bottom:11px;}}
.ft-col a{{display:block;font-size:12px;color:rgba(255,255,255,.35);text-decoration:none;margin-bottom:6px;}}
.ft-col a:hover{{color:#fff;}}
.ft-bot{{max-width:1220px;margin:20px auto 0;display:flex;justify-content:space-between;font-family:"Space Mono",monospace;font-size:9px;}}
.art-page{{max-width:780px;margin:0 auto;padding:44px 32px 80px;}}
.art-bc{{font-family:"Space Mono",monospace;font-size:9px;letter-spacing:1px;text-transform:uppercase;color:var(--mist);margin-bottom:18px;}}
.art-bc a{{color:var(--red);text-decoration:none;cursor:pointer;}}
.art-hl{{font-family:"Playfair Display",serif;font-weight:900;font-size:clamp(1.8rem,4vw,2.8rem);line-height:1.13;color:var(--ink);margin-bottom:16px;letter-spacing:-.3px;}}
.art-deck{{font-size:1.1rem;font-weight:300;color:#444;line-height:1.65;margin-bottom:20px;border-left:4px solid var(--red);padding-left:16px;font-style:italic;}}
.art-by{{display:flex;align-items:center;gap:11px;padding:13px 0;border-top:1px solid var(--rule);border-bottom:1px solid var(--rule);margin-bottom:32px;}}
.art-av{{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-family:"Playfair Display",serif;font-weight:700;font-size:14px;flex-shrink:0;}}
.art-by-name{{font-family:"Space Mono",monospace;font-size:10px;font-weight:700;color:var(--ink);letter-spacing:.5px;text-transform:uppercase;}}
.art-by-meta{{font-family:"Space Mono",monospace;font-size:9px;color:var(--mist);}}
.art-hero{{width:100%;height:320px;margin-bottom:8px;display:flex;align-items:center;justify-content:center;font-size:80px;position:relative;overflow:hidden;border-radius:2px;}}
.art-hero-cap{{font-family:"Space Mono",monospace;font-size:9px;color:var(--mist);margin-bottom:28px;font-style:italic;}}
.art-body p{{margin-bottom:20px;font-size:1rem;line-height:1.85;color:#1a1a1a;}}
.art-body h3{{font-family:"Playfair Display",serif;font-size:1.35rem;font-weight:700;color:var(--ink);margin:36px 0 13px;padding-top:28px;border-top:2px solid var(--rule);}}
.art-body blockquote{{margin:32px 0;padding:20px 24px;background:var(--cream);border-left:5px solid var(--gold);font-style:italic;font-size:1.08rem;color:#333;line-height:1.7;}}
.art-body blockquote cite{{display:block;margin-top:9px;font-family:"Space Mono",monospace;font-size:9px;font-style:normal;color:var(--mist);letter-spacing:1px;text-transform:uppercase;}}
.pull-quote{{font-family:"Playfair Display",serif;font-size:1.45rem;font-weight:700;font-style:italic;color:var(--red);text-align:center;padding:28px 0;border-top:3px solid var(--red);border-bottom:3px solid var(--red);margin:36px 0;line-height:1.3;}}
.fact-box{{background:var(--blue);color:#fff;padding:24px;margin:32px 0;}}
.fact-box-title{{font-family:"Space Mono",monospace;font-size:9px;letter-spacing:2px;text-transform:uppercase;color:var(--gold);margin-bottom:12px;}}
.fact-box ul{{list-style:none;}}
.fact-box ul li{{font-size:13px;padding:6px 0;border-bottom:1px solid rgba(255,255,255,.1);display:flex;justify-content:space-between;color:rgba(255,255,255,.82);}}
.fact-box ul li:last-child{{border-bottom:none;}}
.fact-box ul li strong{{color:#fff;font-family:"Space Mono",monospace;font-size:12px;}}
.art-tags{{margin-top:40px;padding-top:20px;border-top:2px solid var(--rule);display:flex;flex-wrap:wrap;gap:6px;}}
.atag{{font-family:"Space Mono",monospace;font-size:9px;letter-spacing:1px;text-transform:uppercase;border:1px solid var(--rule);padding:4px 10px;color:var(--mist);cursor:pointer;transition:all .2s;}}
.atag:hover{{border-color:var(--ink);color:var(--ink);}}
.art-nav{{display:grid;grid-template-columns:1fr 1fr;gap:2px;background:var(--rule);border:2px solid var(--rule);margin-top:40px;}}
.art-nav-item{{background:var(--surf);padding:18px;cursor:pointer;transition:background .15s;}}
.art-nav-item:hover{{background:var(--cream);}}
.art-nav-item.next{{text-align:right;}}
.art-nav-dir{{font-family:"Space Mono",monospace;font-size:9px;letter-spacing:1px;text-transform:uppercase;color:var(--mist);margin-bottom:5px;}}
.art-nav-hl{{font-family:"Playfair Display",serif;font-weight:700;font-size:.92rem;color:var(--ink);line-height:1.3;}}
.art-nav-item:hover .art-nav-hl{{color:var(--red);}}
.back-btn{{font-family:"Space Mono",monospace;font-size:10px;letter-spacing:1px;text-transform:uppercase;color:var(--red);cursor:pointer;display:inline-flex;align-items:center;gap:5px;margin-top:26px;padding-top:26px;border-top:1px solid var(--rule);text-decoration:none;}}
.cat-page{{max-width:1100px;margin:0 auto;padding:36px 32px 80px;}}
.cat-hd{{text-align:center;padding:26px 0 30px;border-bottom:3px double var(--rule);margin-bottom:32px;}}
.cat-name{{font-family:"Playfair Display",serif;font-size:2.2rem;font-weight:900;color:var(--ink);}}
.cat-desc{{font-size:13px;color:var(--mist);margin-top:6px;}}
.cat-grid{{display:grid;grid-template-columns:repeat(3,1fr);gap:2px;background:var(--rule);border:2px solid var(--rule);}}
#app-root>*{{animation:fi .3s ease;}}
@keyframes fi{{from{{opacity:0;transform:translateY(5px)}}to{{opacity:1;transform:translateY(0)}}}}
@media(max-width:900px){{
  .container,.art-page,.cat-page{{padding:0 16px;}}
  .masthead,.markets,.live-sec .container{{padding-left:16px;padding-right:16px;}}
  .hero-grid,.bot-grid{{grid-template-columns:1fr;}}
  .card-grid,.op-strip,.cat-grid{{grid-template-columns:1fr 1fr;}}
  .dark-feat{{grid-template-columns:1fr;}}
  .df-vis{{display:none;}}
  .ft-inner{{grid-template-columns:1fr 1fr;}}
  .sidebar{{display:none;}}
  .art-nav{{grid-template-columns:1fr;}}
}}
@media(max-width:540px){{
  .card-grid,.op-strip,.cat-grid{{grid-template-columns:1fr;}}
  .ft-inner{{grid-template-columns:1fr;}}
}}
</style>
</head>
<body>
<div id="app-root"></div>
<script>
// ── DATA injected by auto-publisher ──
var DATA = {data_json};

// ── ROUTER ──
var state = {{ page:'home', articleId:null, category:'All', navActive:'All', searchOpen:false }};

function nav(page, param) {{
  state.page = page;
  if(page==='article') state.articleId = param;
  if(page==='category') {{ state.category = param; state.navActive = param; }}
  if(page==='home') state.navActive = 'All';
  window.scrollTo(0,0);
  render();
}}

// ── HELPERS ──
function getArt(id) {{ return DATA.articles.concat([DATA.claude_ai_article]).find(function(a){{return a.id===id;}}); }}
function getByCat(cat) {{
  var all = DATA.articles.concat([DATA.claude_ai_article]);
  if(cat==='All') return all;
  return all.filter(function(a){{return a.cat===cat;}});
}}
var CATS = ['All','Geopolitics','Middle East','Claude AI','Europe','Asia','Economy','Science','Opinion'];
var gradMap = {{
  '#0f1520':'linear-gradient(160deg,#0f1520,#1a3a58)',
  '#0d1000':'linear-gradient(160deg,#0d1000,#1a2a08)',
  '#0d0d1a':'linear-gradient(160deg,#0d0d1a,#1a1030)',
  default:'linear-gradient(160deg,#0f1520,#1a2a38)'
}};
function grad(c) {{ return gradMap[c] || gradMap.default; }}

// ── COMPONENTS ──
function ticker() {{
  var t = DATA.breaking_ticker; var d = t.concat(t);
  return '<div class="ticker"><div class="ticker-tag">⚡ Breaking</div><div class="ticker-track"><div class="ticker-inner">' +
    d.map(function(x){{return '<span>'+x+'</span>';}}).join('') +
  '</div></div></div>';
}}

function masthead() {{
  return '<header class="masthead"><div class="mast-top">' +
    '<div class="mast-date">' + DATA.date + '</div>' +
    '<div class="mast-logo"><a class="logo-name" onclick="nav(\'home\')" href="#" onclick="event.preventDefault()">WORLD<span>PULSE</span></a>' +
    '<div class="logo-tag">{tagline}</div></div>' +
    '<div class="mast-actions"><button class="btn-sub" onclick="openSub()">Subscribe</button></div>' +
  '</div><nav class="nav">' +
    CATS.map(function(c){{
      return '<a class="nav-item'+(state.navActive===c?' active':'')+'" onclick="nav(\'category\',\''+c+'\')" href="#" onclick="event.preventDefault()">'+c+'</a>';
    }}).join('') +
  '</nav></header>';
}}

function markets() {{
  return '<div class="markets">' +
    DATA.markets.map(function(m){{
      return '<div class="m-item"><span class="m-label">'+m.label+'</span>' +
        '<span class="m-val">'+m.value+'</span>' +
        '<span class="m-chg '+m.dir+'">'+m.change+'</span></div>';
    }}).join('') + '</div>';
}}

function heroGrid() {{
  var arts = DATA.articles;
  var lead = arts[0], s1 = arts[1]||DATA.claude_ai_article, s2 = DATA.claude_ai_article;
  return '<div class="hero-grid">' +
    '<div class="hero-lead">' +
      '<div class="hero-img" style="background:'+grad(lead.hero_color||'#0f1520')+';cursor:pointer" onclick="nav(\'article\',\''+lead.id+'\')">' +
        '<span style="opacity:.15">'+lead.hero_icon+'</span>' +
      '</div>' +
      '<div class="kicker">'+lead.tag+'</div>' +
      '<h1 class="hero-hl" onclick="nav(\'article\',\''+lead.id+'\')">'+lead.headline+'</h1>' +
      '<div class="deck">'+lead.deck.substring(0,220)+'…</div>' +
      '<a class="read-btn" onclick="nav(\'article\',\''+lead.id+'\')">Continue Reading →</a>' +
      '<div class="byline"><strong>'+lead.author+'</strong> · '+lead.role+' · '+lead.time+'</div>' +
    '</div>' +
    '<div>' +
      [s1,s2].map(function(a){{
        return '<div class="hero-side">' +
          '<div class="side-img" style="background:'+grad(a.hero_color||'#0f1520')+';cursor:pointer" onclick="nav(\'article\',\''+a.id+'\')">' +
            '<span>'+a.hero_icon+'</span></div>' +
          '<div class="kicker '+(a.cat==='Claude AI'?'teal':'gold')+'">'+a.tag+'</div>' +
          '<div class="hl2" onclick="nav(\'article\',\''+a.id+'\')">'+a.headline+'</div>' +
          '<div class="deck2">'+a.deck.substring(0,160)+'…</div>' +
          '<a class="read-btn" style="color:var(--'+(a.cat==='Claude AI'?'teal':'gold')+')" onclick="nav(\'article\',\''+a.id+'\')">Read More →</a>' +
        '</div>';
      }}).join('') +
    '</div></div>';
}}

function cardGrid() {{
  return '<div class="card-grid">' +
    DATA.articles.slice(2,5).map(function(a){{
      return '<div class="card" onclick="nav(\'article\',\''+a.id+'\')">' +
        '<div class="card-img" style="background:'+grad(a.hero_color||'#0f1520')+'"><span>'+a.hero_icon+'</span></div>' +
        '<div class="kicker">'+a.tag+'</div>' +
        '<div class="hl3">'+a.headline+'</div>' +
        '<div class="deck3">'+a.deck.substring(0,120)+'…</div>' +
        '<div class="byline" style="margin-top:9px"><strong>'+a.author+'</strong> · '+a.time+'</div>' +
      '</div>';
    }}).join('') + '</div>';
}}

function darkFeat() {{
  var a = DATA.claude_ai_article;
  return '<div class="dark-feat" onclick="nav(\'article\',\''+a.id+'\')"><div>' +
    '<div class="df-kicker">✦ Claude AI Column · Weekly</div>' +
    '<div class="df-hl">'+a.headline+'</div>' +
    '<div class="df-deck">'+a.deck.substring(0,220)+'…</div>' +
    '<a class="df-read" onclick="event.stopPropagation();nav(\'article\',\''+a.id+'\')">Read Full Column →</a>' +
  '</div><div class="df-vis">🧠</div></div>';
}}

function opStrip() {{
  var ops = [
    {{label:'Opinion',av:'R',bg:'#c41e3a',author:'Robert Kagan · Foreign Policy',hl:'"The Most Important Diplomacy Since the Cold War"'}},
    {{label:'Analysis',av:'A',bg:'#1a3a5c',author:'Amina Diallo · Economics',hl:'"The Numbers Behind Today\'s Biggest Economic Story"'}},
    {{label:'AI Desk',av:'J',bg:'#3a1a5c',author:'James Park · Technology',hl:'"What Claude\'s New Capabilities Actually Mean"'}},
    {{label:'Climate Desk',av:'S',bg:'#1a4a2e',author:'Sofia Reyes · Climate',hl:'"Today\'s Crisis and Its Climate Dimension"'}}
  ];
  return '<div class="op-strip">' + ops.map(function(op){{
    return '<div class="op-card"><div class="op-label">'+op.label+'</div>' +
      '<div class="op-av" style="background:'+op.bg+'">'+op.av+'</div>' +
      '<div class="op-author">'+op.author+'</div>' +
      '<div class="op-hl">'+op.hl+'</div></div>';
  }}).join('') + '</div>';
}}

function liveSec() {{
  var now = new Date();
  function tAgo(m){{ var t=new Date(now-m*60000); return (t.getHours()<10?'0':'')+t.getHours()+':'+(t.getMinutes()<10?'0':'')+t.getMinutes()+' GMT'; }}
  var offsets = [6,28,52,90];
  return '<div class="live-sec"><div class="container">' +
    '<div class="live-badge"><div class="live-dot"></div>Live Updates</div>' +
    '<div class="live-title">Global Situation Room — ' + DATA.date + '</div>' +
    '<div>' + DATA.live_updates.map(function(u,i){{
      return '<div class="u-item"><div class="u-time">'+tAgo(offsets[i]||i*25+8)+'</div>' +
        '<div class="u-text"><span class="utag '+u.tag+'">'+u.tag_label+'</span>'+u.text+'</div></div>';
    }}).join('') + '</div></div></div>';
}}

function botGrid() {{
  var all = DATA.articles.concat([DATA.claude_ai_article]);
  return '<div class="bot-grid"><div class="most-read">' +
    '<div class="sec-hd" style="margin:0 0 14px"><div class="sec-title" style="font-size:1.1rem">Most Read Today</div><div class="sec-rule"></div></div>' +
    all.slice(0,5).map(function(a,i){{
      return '<div class="mr-item" onclick="nav(\'article\',\''+a.id+'\')">' +
        '<div class="mr-num">0'+(i+1)+'</div>' +
        '<div><div class="mr-title">'+a.headline+'</div><div class="mr-meta">'+a.cat+' · '+a.read_time+'</div></div>' +
      '</div>';
    }}).join('') +
  '</div>' +
  '<div class="sidebar"><div class="sb-w"><div class="sb-title">✉ Morning Briefing</div>' +
    '<div class="nl-w"><p>The world\'s most important stories delivered at 6 AM. Free, always.</p>' +
    '<input type="email" placeholder="your@email.com"/><button>Subscribe Free →</button></div>' +
  '</div></div></div>';
}}

function footer() {{
  return '<footer><div class="ft-inner">' +
    '<div class="ft-brand"><a class="ft-logo" onclick="nav(\'home\')" href="#">WORLD<span>PULSE</span></a>' +
    '<p>Independent global journalism covering conflict, economy, technology, and the decisions that shape our world. Published daily.</p></div>' +
    '<div class="ft-col"><h4>Sections</h4>' + ['Geopolitics','Middle East','Claude AI','Economy','Europe'].map(function(c){{return '<a onclick="nav(\'category\',\''+c+'\')" href="#">'+c+'</a>';}}).join('') + '</div>' +
    '<div class="ft-col"><h4>Company</h4>' + ['About Us','Our Journalists','Contact Us','Press Freedom'].map(function(p){{return '<a href="#">'+p+'</a>';}}).join('') + '</div>' +
    '<div class="ft-col"><h4>Subscribe</h4>' + ['Daily Briefing','Weekly Digest','Claude AI Column','Podcast'].map(function(p){{return '<a href="#">'+p+'</a>';}}).join('') + '</div>' +
  '</div><div class="ft-bot"><span>© '+new Date().getFullYear()+' WorldPulse. All rights reserved.</span><span>Privacy · Terms</span></div></footer>';
}}

function buildHome() {{
  return '<div>' + ticker() + masthead() + markets() +
    '<div class="container">' +
      heroGrid() +
      '<div class="sec-hd"><div class="sec-title">Today\'s Coverage</div><div class="sec-rule red"></div><span style="font-family:\'Space Mono\',monospace;font-size:9px;color:var(--mist)">'+DATA.date+'</span></div>' +
      cardGrid() + darkFeat() +
      '<div class="sec-hd"><div class="sec-title">Analysis & Opinion</div><div class="sec-rule"></div></div>' +
      opStrip() +
    '</div>' +
    liveSec() +
    '<div class="container">' + botGrid() + '</div>' +
    footer() + '</div>';
}}

function buildArticle(id) {{
  var a = getArt(id);
  if(!a) return '<div class="container" style="padding:60px 0"><h2>Not found</h2><a class="back-btn" onclick="nav(\'home\')">← Home</a></div>';
  var all = DATA.articles.concat([DATA.claude_ai_article]);
  var idx = all.findIndex(function(x){{return x.id===id;}});
  var prev = all[idx-1], next = all[idx+1];
  return '<div>' + ticker() + masthead() +
    '<div class="art-page">' +
      '<div class="art-bc"><a onclick="nav(\'home\')" href="#">WorldPulse</a> › <a onclick="nav(\'category\',\''+a.cat+'\')" href="#">'+a.cat+'</a> › '+a.headline.substring(0,35)+'…</div>' +
      '<div class="kicker">'+a.tag+'</div>' +
      '<h1 class="art-hl">'+a.headline+'</h1>' +
      '<div class="art-deck">'+a.deck+'</div>' +
      '<div class="art-by">' +
        '<div class="art-av" style="background:'+('#1a3a5c')+'">'+a.author.charAt(0)+'</div>' +
        '<div><div class="art-by-name">'+a.author+'</div><div class="art-by-meta">'+a.role+' · '+a.time+' · '+a.read_time+'</div></div>' +
        '<div style="margin-left:auto;display:flex;gap:8px">' +
          '<button style="background:transparent;border:1px solid var(--rule);color:var(--mist);padding:5px 11px;font-family:Space Mono,monospace;font-size:9px;cursor:pointer">Share</button>' +
          '<button style="background:transparent;border:1px solid var(--rule);color:var(--mist);padding:5px 11px;font-family:Space Mono,monospace;font-size:9px;cursor:pointer">Save</button>' +
        '</div>' +
      '</div>' +
      '<div class="art-hero" style="background:'+grad(a.hero_color||'#0f1520')+'">' +
        '<span style="opacity:.15">'+a.hero_icon+'</span>' +
      '</div>' +
      '<div class="art-hero-cap">'+a.cat+' · WorldPulse · '+a.time+'</div>' +
      '<div class="art-body">' + (a.body_html||'<p>Full article loading…</p>') + '</div>' +
      '<div class="art-tags"><span class="atag">'+a.cat+'</span><span class="atag">WorldPulse</span><span class="atag">'+DATA.date+'</span></div>' +
      '<div class="art-nav">' +
        (prev?'<div class="art-nav-item" onclick="nav(\'article\',\''+prev.id+'\')"><div class="art-nav-dir">← Previous</div><div class="art-nav-hl">'+prev.headline+'</div></div>':'<div></div>') +
        (next?'<div class="art-nav-item next" onclick="nav(\'article\',\''+next.id+'\')"><div class="art-nav-dir">Next →</div><div class="art-nav-hl">'+next.headline+'</div></div>':'<div></div>') +
      '</div>' +
      '<a class="back-btn" onclick="nav(\'home\')" href="#">← Back to WorldPulse</a>' +
    '</div>' + footer() + '</div>';
}}

function buildCategory(cat) {{
  var arts = getByCat(cat);
  return '<div>' + ticker() + masthead() +
    '<div class="cat-page">' +
      '<div class="cat-hd"><div class="cat-name">'+(cat==='All'?'All Stories':cat)+'</div>' +
      '<div class="cat-desc">'+arts.length+' article'+(arts.length!==1?'s':'')+' · '+DATA.date+'</div></div>' +
      '<div class="cat-grid">' + arts.map(function(a){{
        return '<div class="card" onclick="nav(\'article\',\''+a.id+'\')">'+
          '<div class="card-img" style="background:'+grad(a.hero_color||'#0f1520')+'"><span>'+a.hero_icon+'</span></div>'+
          '<div class="kicker">'+a.tag+'</div>' +
          '<div class="hl3">'+a.headline+'</div>' +
          '<div class="deck3">'+a.deck.substring(0,130)+'…</div>' +
          '<div class="byline" style="margin-top:8px"><strong>'+a.author+'</strong> · '+a.time+'</div>' +
        '</div>';
      }}).join('') + '</div>' +
      '<a class="back-btn" onclick="nav(\'home\')" href="#">← Back to WorldPulse</a>' +
    '</div>' + footer() + '</div>';
}}

function render() {{
  var root = document.getElementById('app-root');
  if(state.page==='home') root.innerHTML = buildHome();
  else if(state.page==='article') root.innerHTML = buildArticle(state.articleId);
  else if(state.page==='category') root.innerHTML = buildCategory(state.category);
}}

function openSub() {{ alert('Subscribe feature — connect to Mailchimp or ConvertKit for real email subscriptions!'); }}

render();
</script>
</body>
</html>
'''

# ─────────────────────────────────────────────
# MAIN PUBLISHER
# ─────────────────────────────────────────────

def call_claude_api(prompt_user, prompt_system):
    """Call Anthropic API and return the response text."""
    if not API_KEY:
        raise ValueError("ANTHROPIC_API_KEY environment variable is not set!")

    payload = {
        "model": MODEL,
        "max_tokens": MAX_TOKENS,
        "messages": [{"role": "user", "content": prompt_user}],
        "system": prompt_system
    }

    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "x-api-key": API_KEY,
            "anthropic-version": "2023-06-01"
        },
        method="POST"
    )

    try:
        with urllib.request.urlopen(req, timeout=120) as response:
            result = json.loads(response.read().decode("utf-8"))
            return result["content"][0]["text"]
    except urllib.error.HTTPError as e:
        error_body = e.read().decode("utf-8")
        raise Exception(f"API Error {e.code}: {error_body}")


def generate_blog():
    """Generate today's complete blog post using Claude."""
    today = datetime.datetime.now().strftime("%A, %B %d, %Y")
    print(f"[WorldPulse Auto-Publisher] Generating blog for {today}…")

    system = SYSTEM_PROMPT.format(today=today)
    user = USER_PROMPT.format(today=today)

    print("[WorldPulse] Calling Claude API…")
    raw = call_claude_api(user, system)

    # Strip any markdown code fences if present
    text = raw.strip()
    if text.startswith("```json"):
        text = text[7:]
    if text.startswith("```"):
        text = text[3:]
    if text.endswith("```"):
        text = text[:-3]
    text = text.strip()

    print("[WorldPulse] Parsing JSON response…")
    data = json.loads(text)

    # Validate required fields
    required = ["date", "articles", "claude_ai_article", "live_updates", "markets", "breaking_ticker"]
    for field in required:
        if field not in data:
            raise ValueError(f"Missing required field in API response: {field}")

    if len(data["articles"]) < 3:
        raise ValueError("API returned fewer than 3 articles — retrying may help")

    print(f"[WorldPulse] Generated {len(data['articles'])} articles + 1 Claude AI column")
    return data


def build_html(data):
    """Inject data into the HTML template and return the complete page."""
    data_json = json.dumps(data, ensure_ascii=False, indent=2)
    html = HTML_TEMPLATE.format(
        blog_title=BLOG_TITLE,
        tagline=BLOG_TAGLINE,
        date=data.get("date", "Today"),
        data_json=data_json
    )
    return html


def publish():
    """Main entry point — generate blog and write HTML file."""
    print("=" * 60)
    print("  WorldPulse Auto-Publisher")
    print(f"  {datetime.datetime.now().strftime('%Y-%m-%d %H:%M UTC')}")
    print("=" * 60)

    # Generate content
    data = generate_blog()

    # Build HTML
    print("[WorldPulse] Building HTML page…")
    html = build_html(data)

    # Write output
    print(f"[WorldPulse] Writing {OUTPUT_FILE}…")
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        f.write(html)

    file_size = os.path.getsize(OUTPUT_FILE)
    print(f"[WorldPulse] ✅ Done! {OUTPUT_FILE} written ({file_size:,} bytes)")
    print(f"[WorldPulse] Today's lead story: {data['articles'][0]['headline'][:70]}…")
    print(f"[WorldPulse] Claude AI column: {data['claude_ai_article']['headline'][:70]}…")
    print("=" * 60)


if __name__ == "__main__":
    publish()
